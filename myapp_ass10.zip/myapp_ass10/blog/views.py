from django.shortcuts import render, redirect
from .models import Post
from .forms import PostForm

def index(request):
    posts = Post.objects.all().order_by('-created_at')  # Latest posts first
    return render(request, 'blog/index.html', {'posts': posts})

def index(request):
    posts = Post.objects.all().order_by('-created_at')  # Latest posts first
    return render(request, 'blog/index.html', {'posts': posts})

def create_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)  # Handle file uploads (images)
        if form.is_valid():
            form.save()
            return redirect('index')  # Redirect to homepage after saving the post
    else:
        form = PostForm()
    return render(request, 'blog/create_post.html', {'form': form})