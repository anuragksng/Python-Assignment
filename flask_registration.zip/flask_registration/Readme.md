cd flask_registration
run : python app.py