from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)

# Configuration for file uploads
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024  # Max file size: 2MB
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

# In-memory database (for simplicity)
users = []

# Function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        profile_picture = request.files['profile_picture']

        if profile_picture and allowed_file(profile_picture.filename):
            filename = secure_filename(profile_picture.filename)
            profile_picture.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            users.append({'username': username, 'email': email, 'profile_picture': filename})
            return redirect(url_for('profile', username=username))
        else:
            return "Invalid file format. Only PNG, JPG, JPEG, and GIF are allowed."

    return render_template('register.html')

@app.route('/profile/<username>')
def profile(username):
    user = next((u for u in users if u['username'] == username), None)
    if user:
        return render_template('profile.html', user=user)
    else:
        return "User not found."

@app.route('/search', methods=['GET', 'POST'])
def search():
    query = request.args.get('query')
    results = [user for user in users if query.lower() in user['username'].lower()]
    return render_template('search_results.html', query=query, results=results)

if __name__ == '__main__':
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(debug=True)
