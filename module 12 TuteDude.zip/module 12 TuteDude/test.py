import psycopg2
def table():
    connect = psycopg2.connect(dbname="postgres", user="postgres", password="123", host="localhost", port="5432")

    cursor = connect.cursor()
    cursor.execute(''' create table employees(Name Text, ID int, Age int);''')
    print('Table created successfully')

    connect.commit()
    connect.close()


def data():
    connect = psycopg2.connect(dbname="postgres", user="postgres", password="123", host="localhost", port="5432")

    cursor = connect.cursor()
    
    name = input("Enter name: ")
    ID = (input("Enter ID: "))
    age = (input("Enter age: "))

    query = ''' insert into employees(Name, ID , Age) values(%s,%s,%s);'''
    cursor.execute(query,(name,ID,age))
    print('Data added successfully')

    connect.commit()
    connect.close()

data()