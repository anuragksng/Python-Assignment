from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from helloworld.views import HelloWorldView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('blog.urls')),  # Include app-level URLs
    path('hello' , HelloWorldView.as_view())
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
