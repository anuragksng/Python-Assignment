from django.urls import path, include
from .views import index, create_post
from django.contrib import admin
from helloworld.views import HelloWorldView
from rest_framework import routers
from helloworld.views import PostView

urlpatterns = [

    path('admin/', admin.site.urls),
    path('', index, name='index'),
    path('hello', HelloWorldView.as_view()),
    path('api-auth/', include('rest_framework.urls')),
    path('create/', create_post, name='create_post'),  # Route for creating posts
]

router = routers.SimpleRouter()
router.register('post', PostView, basename="post")

urlpatterns+= router.urls