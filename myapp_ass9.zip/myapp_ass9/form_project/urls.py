from django.contrib import admin
from django.urls import path
from app.views import contact_view, success_view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', contact_view, name='contact'),
    path('success/', success_view, name='success'),
]
