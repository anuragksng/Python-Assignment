# Django Registration and Login Integrated Project

This project integrates user registration and login functionalities into a single Django application using Django's built-in authentication system.

