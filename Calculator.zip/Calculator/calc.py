import tkinter as tk  

class Calculator:  
    def __init__(self, root):  
        self.root = root  
        self.root.title("Calculator")  

        # Entry widget to display calculations  
        self.expression = ""  
        self.entry = tk.Entry(root, width=16, font=('Arial', 24), borderwidth=5, relief='ridge')  
        self.entry.grid(row=0, column=0, columnspan=4)  

        self.create_buttons()  

    def create_buttons(self):  
        buttons = [  
            '7', '8', '9', '/',  
            '4', '5', '6', '*',  
            '1', '2', '3', '-',  
            '0', '.', '=', '+',  
            'C'  
        ]  

        row_value = 1  
        col_value = 0  

        for button in buttons:  
            action = lambda x=button: self.click(x)  
            tk.Button(self.root, text=button, padx=20, pady=20, font=('Arial', 18),   
                      command=action).grid(row=row_value, column=col_value)  

            col_value += 1  
            if col_value > 3:  
                col_value = 0  
                row_value += 1  

    def click(self, item):  
        if item == 'C':  
            self.expression = ""  
            self.entry.delete(0, tk.END)  
        elif item == '=':  
            try:  
                result = str(eval(self.expression))  
                self.entry.delete(0, tk.END)  
                self.entry.insert(tk.END, result)  
                self.expression = result  # For chaining operations  
            except Exception as e:  
                self.entry.delete(0, tk.END)  
                self.entry.insert(tk.END, "Error")  
                self.expression = ""  
        else:  
            self.expression += str(item)  
            self.entry.delete(0, tk.END)  
            self.entry.insert(tk.END, self.expression)  

if __name__ == "__main__":  
    root = tk.Tk()  
    calculator = Calculator(root)  
    root.mainloop()  